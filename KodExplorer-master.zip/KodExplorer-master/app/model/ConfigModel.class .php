<?php
class ConfigModel extends Model{
}

